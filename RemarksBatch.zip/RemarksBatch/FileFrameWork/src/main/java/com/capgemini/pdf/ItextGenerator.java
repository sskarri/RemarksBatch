package com.capgemini.pdf;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.springframework.stereotype.Component;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.tool.xml.XMLWorkerHelper;
 
@Component
public class ItextGenerator {


	 

	    /**
	     * Creates a PDF with the words "Hello World"
	     * @param file
	     * @throws IOException
	     * @throws DocumentException
	     */
	
	    public void createPdf(File hf,File pf,File cf) throws IOException, DocumentException {
	        // step 1
	    	
	    	/* float left = 30;
	         float right = 30;
	         float top = 60;
	         float bottom = 0;
	         Document document = new Document(PageSize.A4, left, right, top, bottom);*/
	        Document document = new Document();
	        // step 2
	        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(pf));
	        writer.setInitialLeading(12);
	        // step 3
	        document.open();
	        // step 4
	     
	        XMLWorkerHelper.getInstance().parseXHtml(writer, document,
	                new FileInputStream(hf),new FileInputStream(cf));
	        // step 5
	        /*   PdfContentByte canvas = writer.getDirectContentUnder();
	     Image image = Image.getInstance(FileCreators.getResourcePath("images")+"/"+"logo.png");
	        image.scaleAbsolute(PageSize.A4.rotate());
	        image.setAbsolutePosition(0, PageSize.A4.getHeight() - image.getScaledHeight());
	        canvas.addImage(image);*/
	        document.close();
	        hf.delete();
	    }
	
}
