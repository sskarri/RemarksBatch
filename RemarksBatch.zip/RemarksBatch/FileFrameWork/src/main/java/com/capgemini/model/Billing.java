/**
 * 
 */
package com.capgemini.model;

import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.stereotype.Component;

/**
 * @author shysatya
 *
 */
@Component
@XmlRootElement(name="billing")
public class Billing {

	/**
	 * 
	 */
	public Billing(){
		
		
	}
 
	private String CustomerId;
	public String getCustomerId() {
		return CustomerId;
	}
	public void setCustomerId(String customerId) {
		this.CustomerId = customerId;
	}
	public String getCustomerName() {
		return CustomerName;
	}
	public void setCustomerName(String customerName) {
		this.CustomerName = customerName;
	}
	public String getRate() {
		return Rate;
	}
	public void setRate(String rate) {
		this.Rate = rate;
	}
	public String getQty() {
		return Qty;
	}
	public void setQty(String qty) {
		this.Qty = qty;
	}
	public String getCurrent_Balance() {
		return Current_Balance;
	}
	public void setCurrent_Balance(String current_Balance) {
		this.Current_Balance = current_Balance;
	}
	public String getOld_Balance() {
		return Old_Balance;
	}
	public void setOld_Balance(String old_Balance) {
		this.Old_Balance = old_Balance;
	}
	public String getTotal() {
		return Total;
	}
	public void setTotal(String total) {
		this.Total = total;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		this.State = state;
	}
	public String getArea() {
		return Area;
	}
	public void setArea(String area) {
		this.Area = area;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		this.City = city;
	}
	public String getMonth() {
		return Month;
	}
	public void setMonth(String month) {
		this.Month = month;
	}
	public String getYear() {
		return Year;
	}
	public void setYear(String year) {
		this.Year = year;
	}
	public String getBilling_Date() {
		return Billing_Date;
	}
	public void setBilling_Date(String billing_Date) {
		this.Billing_Date = billing_Date;
	}
	private String CustomerName;
	private String Rate;
	private String Qty;
	private String Current_Balance;
	private String Old_Balance;
	private String Total;
	private String State;
	private String Area;
	private String City;
	private String Month;
	private String Year;
	private String Billing_Date;

	   @Override
	    public String toString() {
	        return new ToStringBuilder(this)
	                .append("CustomerName", this.CustomerName)
	                .append("Rate", this.Rate)
	                .append("Qty", this.Qty)
	                .append("Current_Balance", this.Current_Balance)
	                .append("Old_Balance", this.Old_Balance)
	                .append("Total", this.Total)
	                .append("State", this.State)
	                .append("Area", this.Area)
	                .append("City", this.City)
	                .append("Month", this.Month)
	                .append("Year", this.Year)
	                .append("Billing_Date", this.Billing_Date)
	                .toString();
	    }
	




}
