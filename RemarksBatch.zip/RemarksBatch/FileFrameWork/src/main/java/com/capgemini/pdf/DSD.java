package com.capgemini.pdf;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.springframework.cglib.beans.BeanGenerator;

public class DSD {

	public static void main(final String[] args) throws Exception{
	    final Map<String, Class<?>> properties =
	        new HashMap<String, Class<?>>();
	    properties.put("foo", Integer.class);
	    properties.put("bar", String.class);
	    properties.put("baz", int[].class);
/*
	    final Class<?> beanClass =  SSS.createBeanClass("some.ClassName", properties);
	    System.out.println(beanClass);
	    for(final Method method : beanClass.getDeclaredMethods()){
	        System.out.println(method);
	       
	    }
	    Method setter = beanClass.getClass().getMethod("some.ClassName.setBar", String.class);
        setter.invoke(beanClass, "Some String");
        Method getter = beanClass.getClass().getMethod("some.ClassName.getBar");
        System.out.println(getter.invoke(beanClass));*/
	    BeanGenerator beanGenerator = new BeanGenerator();
	    
	    beanGenerator.addProperty("name", String.class);
	    beanGenerator.addProperty("country", String.class);
	    beanGenerator.addProperty("files", String.class);
	    beanGenerator.addProperty("data", String.class);
	    beanGenerator.addProperty("markup", String.class);

	    
	    Object myBean = beanGenerator.create();
	    Method setter = myBean.getClass().getMethod("setName", String.class);
	    setter.invoke(myBean, "some string value set by a cglib");
	     
	    Method getter = myBean.getClass().getMethod("getName");
	  System.out.println(getter.invoke(myBean));
	}


}
