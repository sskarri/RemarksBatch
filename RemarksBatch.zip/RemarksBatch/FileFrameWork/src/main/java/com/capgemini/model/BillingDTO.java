package com.capgemini.model;

import org.apache.commons.lang3.builder.ToStringBuilder ;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Contains the information of a single student who has purchased
 * the course.
 *
 * @author shysatya
 */
@XmlRootElement(name="billing")
public class BillingDTO {

	private String customerId;
	public String getCustomerId() {
		return customerId;
	}


	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public String getRate() {
		return rate;
	}


	public void setRate(String rate) {
		this.rate = rate;
	}


	public String getQty() {
		return qty;
	}


	public void setQty(String qty) {
		this.qty = qty;
	}


	public String getCurrentBalance() {
		return currentBalance;
	}


	public void setCurrentBalance(String currentBalance) {
		this.currentBalance = currentBalance;
	}


	public String getOldBalance() {
		return oldBalance;
	}


	public void setOldBalance(String oldBalance) {
		this.oldBalance = oldBalance;
	}


	public String getTotal() {
		return total;
	}


	public void setTotal(String total) {
		this.total = total;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getArea() {
		return area;
	}


	public void setArea(String area) {
		this.area = area;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getMonth() {
		return month;
	}


	public void setMonth(String month) {
		this.month = month;
	}


	public String getYear() {
		return year;
	}


	public void setYear(String year) {
		this.year = year;
	}


	public String getBillingDate() {
		return billingDate;
	}


	public void setBillingDate(String billingDate) {
		this.billingDate = billingDate;
	}


	private String customerName;
	private String rate;
	private String qty;
	private String currentBalance;
	private String oldBalance;
	private String total;
	private String state;
	private String area;
	private String city;
	private String month;
	private String year;
	private String billingDate;
	private String gstnId;
	private String remarks;
	
	   public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	public String getGstnId() {
		return gstnId;
	}


	public void setGstnId(String gstnId) {
		this.gstnId = gstnId;
	}


	public BillingDTO() {}
	   
	
	 @Override
	    public String toString() {
	        return new ToStringBuilder(this)
	        		.append("CustomerId",this.customerId)
	                .append("CustomerName", this.customerName)
	                .append("Rate", this.rate)
	                .append("Qty", this.qty)
	                .append("Current_Balance", this.currentBalance)
	                .append("Old_Balance", this.oldBalance)
	                .append("Total", this.total)
	                .append("State", this.state)
	                .append("Area", this.area)
	                .append("City", this.city)
	                .append("Month", this.month)
	                .append("Year", this.year)
	                .append("Billing_Date", this.billingDate)
	                .append("GSTN_ID", this.gstnId)
	                .append("REMARKS",this.remarks)
	                .toString();
	    }
	
}
