package com.capgemini.batch;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;

import com.capgemini.model.BillingDTO;


public class LoggingStudentWriter implements ItemWriter<BillingDTO> {

    private static final Logger LOGGER = LoggerFactory.getLogger(LoggingStudentWriter.class);

    @Override
    public void write(List<? extends BillingDTO> items) throws Exception {
        LOGGER.info("Received the information of {} students", items.size());
        //items.forEach(i -> LOGGER.debug("Received the information of a student: {}", i));
        for(BillingDTO item:items){
        	LOGGER.debug("Received the information of a student: {}", item);
        }
    }
}
