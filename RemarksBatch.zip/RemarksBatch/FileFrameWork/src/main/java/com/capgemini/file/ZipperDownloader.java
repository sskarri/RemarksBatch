/*package com.capgemini.file;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

*//**
 * Servlet implementation class ZipperDownloader
 *//*
@WebServlet("/Download")
public class ZipperDownloader extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    *//**
     * @see HttpServlet#HttpServlet()
     *//*
    public ZipperDownloader() {
        super();
        // TODO Auto-generated constructor stub
    }

	*//**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 *//*
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HashMap<String, Object> map = Utility.getParamMap(request);
		System.out.println(map);
		String [] srcFiles = {};
		Date now = new Date();
	     	DateFormat df1 = DateFormat.getDateInstance(DateFormat.SHORT);
		String s1 = df1.format(now);
		String req =  request.getParameter("invoiceId");
		MongoCollOperations mm = new MongoCollOperations();
		HashMap<String, Object> vals = new HashMap<String, Object>();
		vals.put("invoiceId", req);

		DBObject dbObj = mm.getQueriedDocument("Invoices", vals);
		System.out.println(dbObj);



		// Set the content type based to zip
				response.setContentType("Content-type: text/zip");
		        response.setHeader("Content-Disposition","attachment; filename=\"" + "Invoices"+s1+".zip" + "\"");

				// List of files to be downloaded
				List files = new ArrayList();
				files.add(new File("C:/first.txt"));
				files.add(new File("C:/second.txt"));
				files.add(new File("C:/third.txt"));
				ServletOutputStream out = response.getOutputStream();
				ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(out));

				
				for (String key : dbObj.keySet()) {
				if(!key.equals("_id") && !key.equals("invoiceId")){
					File file = new File(dbObj.get( key ).toString());
					System.out.println("Adding file " + file.getName());
					zos.putNextEntry(new ZipEntry(file.getName()));

					// Get the file
					FileInputStream fis = null;
					try {
						fis = new FileInputStream(file);

					} catch (FileNotFoundException fnfe) {
						// If the file does not exists, write an error entry instead of
						// file
						// contents
						zos.write(("ERROR: Could not find file " + file.getName())
								.getBytes());
						zos.closeEntry();
						System.out.println("Could not find file "
								+ file.getAbsolutePath());
						continue;
					}

					BufferedInputStream fif = new BufferedInputStream(fis);

					// Write the contents of the file
					int data = 0;
					while ((data = fif.read()) != -1) {
						zos.write(data);
					}
					fif.close();

					zos.closeEntry();
					System.out.println("Finished adding file " + file.getName());
				}
				}
				
			

				zos.close();
			
	}

	*//**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 *//*
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
*/