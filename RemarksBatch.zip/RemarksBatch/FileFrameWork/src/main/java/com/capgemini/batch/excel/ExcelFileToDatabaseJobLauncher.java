package com.capgemini.batch.excel;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.capgemini.file.FileCreators;
import com.itextpdf.text.log.SysoCounter;

/**
 * @author shysatya
 */
 @Component
public class ExcelFileToDatabaseJobLauncher {


    private static final Logger LOGGER = LoggerFactory.getLogger(ExcelFileToDatabaseJobLauncher.class);

    private final Job job;

    private final JobLauncher jobLauncher;

    @Autowired
    ExcelFileToDatabaseJobLauncher(@Qualifier("excelFileToDatabaseJob") Job job, JobLauncher jobLauncher) {
     
    	this.job = job;
        this.jobLauncher = jobLauncher;
    }
    
    public ArrayList<File> launchXmlFileToDatabaseJob() throws JobParametersInvalidException, JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException {
        
    	LOGGER.info("Starting excelFileToDatabase job");
        long startTime = System.nanoTime();
        jobLauncher.run(job, newExecution());
        LOGGER.info("Stopping excelFileToDatabase job");
        long endTime   = System.nanoTime();
        long totalTime = endTime - startTime;
        System.out.println("Total Time Taken In Nano Seconds"+totalTime);
		return FileCreators.files;
        
    }
    private JobParameters newExecution() {
        Map<String, JobParameter> parameters = new HashMap<>();

        JobParameter parameter = new JobParameter(new Date());
        parameters.put("currentTime", parameter);

        return new JobParameters(parameters);
    }
}
