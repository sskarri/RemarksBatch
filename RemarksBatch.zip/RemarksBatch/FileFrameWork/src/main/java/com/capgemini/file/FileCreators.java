package com.capgemini.file;

import java.io.File; 
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import javax.servlet.ServletContext;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.capgemini.pdf.ItextGenerator;
import com.itextpdf.text.DocumentException;

import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
@Component
public class FileCreators {

	

	 public static ArrayList<File> files = new ArrayList<File>();
	public void writeFile(MultipartFile file) throws IOException{
		
		String path =getResourcePath("data").toString();
		
		
		File f = new File(path+"/"+"System.xlsx");
		if (!f.exists()) {
			f.createNewFile();
		}
		FileOutputStream fos = new FileOutputStream(f);
		fos.write(file.getBytes());
		fos.flush();
		fos.close();
	}
	
	public void writeFile(String htmlText,String l) throws IOException, DocumentException{
		String htmlPath =getResourcePath("htmlsrc").toString();
		String pdfPath = getResourcePath("pdfs").toString();

		
		File hf = new File(htmlPath+"/"+l+"htmlsrc.html");
		File pf = new File(pdfPath+"/"+l+"pdfsrc.pdf");
		File cf = new File(htmlPath+"/csssrc.css");
		 files.add(pf);
		if (!hf.exists() && !pf.exists()) {
			
			hf.createNewFile();
			pf.createNewFile();
			
		}
		FileOutputStream fos = new FileOutputStream(hf);
		fos.write(htmlText.getBytes());
		fos.flush();
		fos.close();
		ItextGenerator pdfG = new ItextGenerator();
		pdfG.createPdf(hf, pf,cf);
	}
	public static Path getResourcePath(String endPoint) {
		Path path =null;
	    try {
	    	 path = Paths.get(FileCreators.class.getResource("/"+endPoint).toURI());
	    	return path;
	    } catch (Exception e) {
	    	e.printStackTrace();
	        return null;
	    }
	}

}
