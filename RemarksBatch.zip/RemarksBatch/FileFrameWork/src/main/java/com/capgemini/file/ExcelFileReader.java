package com.capgemini.file;

import java.io.BufferedInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import groovy.lang.Binding;
import groovy.lang.GroovyShell;

@Component
public class ExcelFileReader {

	private static final long serialVersionUID = -6249488544306639050L;
	public static final String script = "import org.apache.poi.ss.usermodel.*; import org.springframework.stereotype.Component;  println attributes.get('dym');";
	private static final Logger LOGGER = LoggerFactory.getLogger(ExcelFileReader.class);

	public void readContents(MultipartFile file) {
		try {
			InputStream inputStream = new BufferedInputStream(file.getInputStream());

			Workbook workbook = new XSSFWorkbook(inputStream);
			Sheet datatypeSheet = workbook.getSheetAt(0);
			Iterator<Row> iterator = datatypeSheet.iterator();

			while (iterator.hasNext()) {

				Row currentRow = iterator.next();
				Iterator<Cell> cellIterator = currentRow.iterator();

				while (cellIterator.hasNext()) {

					Cell currentCell = cellIterator.next();
				/*	// getCellTypeEnum shown as deprecated for version 3.15
					// getCellTypeEnum ill be renamed to getCellType starting
					// from version 4.0
					// System.out.println(currentCell.getRow());
					// fileValidator.validate(currentCell);
					Map<String, Object> h = new HashMap<>();
					h.put("dym",currentCell);
					Object obj = getGroovyAttributeValue(script, h);
*/
				}
				System.out.println();

			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	
	
	private static Object getGroovyAttributeValue(final String groovyScript,
			final Map<String, Object> resolvedAttributes) {
		try {
			final Binding binding = new Binding();
			final GroovyShell shell = new GroovyShell(binding);
			binding.setVariable("attributes", resolvedAttributes);
			binding.setVariable("logger", LOGGER);

			LOGGER.debug("Executing groovy script [{}] with attributes binding of [{}]",
					StringUtils.abbreviate(groovyScript, groovyScript.length() / 2), resolvedAttributes);
			final Object res = shell.evaluate(groovyScript);
			return res;
		} catch (final Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return null;
	}

}
